Name: Eric Faguy 0968958
Description: A simulation a hospital waiting room processing patient based on a priority they are assigned, the time the processing take is based on their symptoms. Taking data in from a txt file specified by a command line argument.
Running make program will compile into a executable called program in the bin directory.
Running make test will compile the test main into a executable called test in the bin directroy.
